library(testthat)
library(metadig)

test_check("metadig")
